var bahasaAktif = 'id';

var teks = {
id:{kembali:'Kembali',subjudul:'Texture Pack Collection',kat_donasi:'Donasi',kat_donasi_desc:'Mau donasi pake apa? Dana? Saweria?',kat_buatku:'Texture Pack Buat Ku',kat_buatku_desc:'Karya orisinal Just Pixel',kat_akupake:'Texture Pack Yang Aku Pake',kat_akupake_desc:'Rekomendasi buat HP kentang',kat_lain:'Texture Pack Lain',kat_lain_desc:'Rekomendasi dari komunitas',donasi_pilih:'Kalau mau support, bisa lewat:',download_batch:'Download Batch',batal:'Batal'},
en:{kembali:'Back',subjudul:'Texture Pack Collection',kat_donasi:'Donation',kat_donasi_desc:'Want to donate? Dana? Saweria?',kat_buatku:'My Texture Packs',kat_buatku_desc:'Original works by Just Pixel',kat_akupake:'Packs I Use',kat_akupake_desc:'Recommended for low-end phones',kat_lain:'Other Packs',kat_lain_desc:'Community recommendations',donasi_pilih:'If you want to support:',download_batch:'Download Batch',batal:'Cancel'},
jp:{kembali:'戻る',subjudul:'テクスチャパックコレクション',kat_donasi:'寄付',kat_donasi_desc:'寄付しませんか？',kat_buatku:'私のパック',kat_buatku_desc:'Just Pixelの作品',kat_akupake:'使用中',kat_akupake_desc:'低スペック向け',kat_lain:'その他',kat_lain_desc:'コミュニティ',donasi_pilih:'サポートはこちら:',download_batch:'一括DL',batal:'キャンセル'},
kr:{kembali:'뒤로',subjudul:'텍스처 팩 컬렉션',kat_donasi:'기부',kat_donasi_desc:'기부하시겠어요?',kat_buatku:'내 팩',kat_buatku_desc:'Just Pixel 작품',kat_akupake:'사용 중',kat_akupake_desc:'저사양 추천',kat_lain:'기타',kat_lain_desc:'커뮤니티',donasi_pilih:'후원하기:',download_batch:'일괄 다운로드',batal:'취소'},
es:{kembali:'Volver',subjudul:'Coleccion de Packs',kat_donasi:'Donacion',kat_donasi_desc:'Quieres donar?',kat_buatku:'Mis Packs',kat_buatku_desc:'Obras de Just Pixel',kat_akupake:'Packs Que Uso',kat_akupake_desc:'Para gama baja',kat_lain:'Otros Packs',kat_lain_desc:'Comunidad',donasi_pilih:'Si quieres apoyar:',download_batch:'Descarga Multiple',batal:'Cancelar'}
};

function gantiBahasa(kode){
bahasaAktif = kode;
var data = teks[kode];
if(!data) return;
var el = document.querySelectorAll('[data-lang]');
for(var i=0;i<el.length;i++){
var k = el[i].getAttribute('data-lang');
if(data[k]) el[i].textContent = data[k];
}
var btn = document.querySelectorAll('.btn-bahasa');
for(var j=0;j<btn.length;j++){
btn[j].classList.remove('active');
if(btn[j].getAttribute('data-bahasa')===kode) btn[j].classList.add('active');
}
localStorage.setItem('justpixel_bahasa', kode);
}

function toggleKategori(header){
var kat = header.parentNode;
kat.classList.toggle('buka');
}

function kembali(){
window.location.href = 'index.html';
}

function donasi(metode){
if(metode === 'dana'){
alert('Donasi via Dana\n\nNomor: 08123456789\nA/N: Just Pixel\n\nGanti nomor di texturepack.js');
}else if(metode === 'saweria'){
window.open('https://saweria.co/justpixel', '_blank');
}else if(metode === 'qris'){
alert('Scan QRIS untuk donasi.\n\n(Ganti dengan QRIS asli kamu)');
}
}

function bukaPreview(id, nama){
document.getElementById('previewTitle').textContent = nama;
var img = document.getElementById('previewImg');
img.src = 'preview-' + id + '.png';
img.onerror = function(){
img.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="280" height="200"><rect width="280" height="200" fill="%232a2a4e"/><text x="140" y="105" font-family="Arial" font-size="14" fill="%239b59b6" text-anchor="middle">Preview</text></svg>';
};
document.getElementById('previewDesc').textContent = 'Preview: ' + nama;
document.getElementById('modalPreview').classList.add('show');
}

function tutupPreview(){
document.getElementById('modalPreview').classList.remove('show');
}

function downloadPack(id){
alert('Download: ' + id + '.zip\n\nGanti link download di texturepack.js');
}

function beriRating(packId, nilai){
localStorage.setItem('justpixel_rating_' + packId, nilai);
updateRating(packId);
}

function updateRating(packId){
var nilai = parseInt(localStorage.getItem('justpixel_rating_' + packId) || '0', 10);
var container = document.querySelector('[data-rating="' + packId + '"]');
if(!container) return;
var bintang = container.querySelectorAll('.star');
for(var i=0;i<bintang.length;i++){
bintang[i].classList.remove('aktif');
if(i < nilai) bintang[i].classList.add('aktif');
}
var nilaiEl = document.getElementById('nilai-' + packId);
if(nilaiEl) nilaiEl.textContent = nilai + '/5';
}

function initRating(){
var packs = document.querySelectorAll('.rating');
for(var i=0;i<packs.length;i++){
var id = packs[i].getAttribute('data-rating');
if(id) updateRating(id);
}
}

var dipilih = [];
function cekBatch(){
var cbs = document.querySelectorAll('.cb-batch');
dipilih = [];
for(var i=0;i<cbs.length;i++){
if(cbs[i].checked) dipilih.push(cbs[i].getAttribute('data-nama'));
}
if(dipilih.length > 0){
document.getElementById('batchBar').classList.add('show');
document.getElementById('batchInfo').textContent = dipilih.length + ' dipilih';
}else{
document.getElementById('batchBar').classList.remove('show');
}
}

function downloadBatch(){
if(dipilih.length === 0){alert('Belum ada yang dipilih');return;}
var pesan = 'Download ' + dipilih.length + ' pack:\n\n';
for(var i=0;i<dipilih.length;i++) pesan += '- ' + dipilih[i] + '\n';
alert(pesan);
}

function batalBatch(){
var cbs = document.querySelectorAll('.cb-batch');
for(var i=0;i<cbs.length;i++) cbs[i].checked = false;
cekBatch();
}

function updateJam(){
var now = new Date();
var jam = String(now.getHours()).padStart(2,'0');
var menit = String(now.getMinutes()).padStart(2,'0');
var detik = String(now.getSeconds()).padStart(2,'0');
var hariArr = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
var bulanArr = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
var elJam = document.getElementById('jamRealtime');
var elTgl = document.getElementById('tanggalRealtime');
if(elJam) elJam.textContent = jam + ':' + menit + ':' + detik;
if(elTgl) elTgl.textContent = hariArr[now.getDay()] + ', ' + now.getDate() + ' ' + bulanArr[now.getMonth()];
}

window.addEventListener('DOMContentLoaded', function(){
var cbs = document.querySelectorAll('.cb-batch');
for(var i=0;i<cbs.length;i++){
cbs[i].addEventListener('change', cekBatch);
}
var bhs = localStorage.getItem('justpixel_bahasa');
if(bhs && teks[bhs]) gantiBahasa(bhs);
initRating();
updateJam();
setInterval(updateJam, 1000);
});
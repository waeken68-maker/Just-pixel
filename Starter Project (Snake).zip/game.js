var backgroundAktif='none';
var palets=[];
var namaKeren=['Senja','Laut','Hutan','Awan','Kristal','Nebula','Aurora','Galaksi','Api','Es','Fajar','Malam'];
var presetTema={
dark:{body:'#1a1a2e',profil:'#2a2a4e',aksen:'#9b59b6'},
light:{body:'#f0f0f0',profil:'#ffffff',aksen:'#3498db'},
cyberpunk:{body:'#0a0014',profil:'#1a0033',aksen:'#ff00ff'},
retro:{body:'#2b1810',profil:'#4a2c1a',aksen:'#f39c12'},
senja:{body:'#2d1b3d',profil:'#4a2c5e',aksen:'#ff6b6b'},
laut:{body:'#0a192f',profil:'#112240',aksen:'#64ffda'}
};
var pickerState={h:270,s:.5,v:.5,target:'body',warnaAwal:'#1a1a2e'};

function hexToRgb(hex){
hex=hex.replace('#','');
if(hex.length===3)hex=hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
return{r:parseInt(hex.substr(0,2),16),g:parseInt(hex.substr(2,2),16),b:parseInt(hex.substr(4,2),16)};
}
function rgbToHex(r,g,b){
var arr=[r,g,b],hasil='#';
for(var i=0;i<3;i++){
var v=Math.round(Math.max(0,Math.min(255,arr[i])));
var h=v.toString(16);
if(h.length===1)h='0'+h;
hasil+=h;
}
return hasil;
}
function rgbToHsv(r,g,b){
r/=255;g/=255;b/=255;
var max=Math.max(r,g,b),min=Math.min(r,g,b),h=0,s=0,v=max,d=max-min;
if(max!==0)s=d/max;
if(max!==min){
if(max===r)h=(g-b)/d+(g<b?6:0);
else if(max===g)h=(b-r)/d+2;
else h=(r-g)/d+4;
h/=6;
}
return{h:h*360,s:s,v:v};
}
function hsvToRgb(h,s,v){
h/=360;
var i=Math.floor(h*6),f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s),r,g,b,m=i%6;
if(m===0){r=v;g=t;b=p;}
else if(m===1){r=q;g=v;b=p;}
else if(m===2){r=p;g=v;b=t;}
else if(m===3){r=p;g=q;b=v;}
else if(m===4){r=t;g=p;b=v;}
else{r=v;g=p;b=q;}
return{r:r*255,g:g*255,b:b*255};
}
function validasiHex(hex){
if(!hex)return null;
if(hex[0]!=='#')hex='#'+hex;
if(!/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex))return null;
return hex;
}
function hitungKecerahan(hex){
var rgb=hexToRgb(hex);
return(rgb.r*299+rgb.g*587+rgb.b*114)/1000;
}
function warnaTeksKontras(hex){
return hitungKecerahan(hex)>150?'#000000':'#ffffff';
}

function simpanPengaturan(){
var el=document.getElementById('pickBody');
if(!el)return;
try{
localStorage.setItem('justpixel_pengaturan',JSON.stringify({
body:el.value,
profil:document.getElementById('pickProfil').value,
aksen:document.getElementById('pickAksen').value,
background:backgroundAktif
}));
}catch(e){}
}
function muatPengaturan(){
var data=localStorage.getItem('justpixel_pengaturan');
if(!data)return;
try{
var p=JSON.parse(data);
if(p.body){
document.getElementById('pickBody').value=p.body;
document.getElementById('display-body').style.background=p.body;
document.getElementById('hexBody').value=p.body;
}
if(p.profil){
document.getElementById('pickProfil').value=p.profil;
document.getElementById('display-profil').style.background=p.profil;
document.getElementById('hexProfil').value=p.profil;
}
if(p.aksen){
document.getElementById('pickAksen').value=p.aksen;
document.getElementById('display-aksen').style.background=p.aksen;
document.getElementById('hexAksen').value=p.aksen;
}
if(p.background)backgroundAktif=p.background;
applySemuaWarna();
}catch(e){}
}
function updateHitCounter(){
try{
if(!sessionStorage.getItem('hitSesiIni')){
var hit=parseInt(localStorage.getItem('justpixel_hits')||'0',10);
hit++;
localStorage.setItem('justpixel_hits',hit);
sessionStorage.setItem('hitSesiIni','1');
}
var el=document.getElementById('hitCounter');
if(el)el.textContent=localStorage.getItem('justpixel_hits')||'0';
}catch(e){}
}

function toggleWarna(){
var p=document.getElementById('pilihanWarna');
var g=document.getElementById('tombolGir');
if(p.classList.contains('show')){
p.classList.remove('show');
g.classList.remove('active');
}else{
p.classList.add('show');
g.classList.add('active');
}
}

function bukaPicker(jenis){
pickerState.target=jenis;
var id='pick'+jenis.charAt(0).toUpperCase()+jenis.slice(1);
var el=document.getElementById(id);
var warna=el?el.value:'#1a1a2e';
pickerState.warnaAwal=warna;
var rgb=hexToRgb(warna);
var hsv=rgbToHsv(rgb.r,rgb.g,rgb.b);
pickerState.h=hsv.h;
pickerState.s=hsv.s;
pickerState.v=hsv.v;
document.getElementById('previewLama').style.background=warna;
updatePickerUI();
generatePresetWarna();
document.getElementById('colorModal').classList.add('show');
}
function generatePresetWarna(){
var preset=['#000','#fff','#9e9e9e','#f44336','#ffeb3b','#4caf50','#00bcd4','#2196f3','#3f51b5','#9c27b0','#e91e63','#ff9800','#795548','#607d8b'];
var c=document.getElementById('presetColors');
c.innerHTML='';
for(var i=0;i<preset.length;i++){
var btn=document.createElement('button');
btn.className='preset-color';
btn.style.background=preset[i];
btn.setAttribute('data-warna',preset[i]);
btn.onclick=function(){pilihPresetWarna(this.getAttribute('data-warna'));};
c.appendChild(btn);
}
}
function pilihPresetWarna(warna){
var rgb=hexToRgb(warna);
var hsv=rgbToHsv(rgb.r,rgb.g,rgb.b);
pickerState.h=hsv.h;
pickerState.s=hsv.s;
pickerState.v=hsv.v;
updatePickerUI();
}
function updatePickerUI(){
var rgbMurni=hsvToRgb(pickerState.h,1,1);
var hexHue=rgbToHex(rgbMurni.r,rgbMurni.g,rgbMurni.b);
document.getElementById('pickerGradient').style.background='linear-gradient(to top,#000,transparent),linear-gradient(to right,#fff,transparent),'+hexHue;
document.getElementById('gradientCursor').style.left=(pickerState.s*100)+'%';
document.getElementById('gradientCursor').style.top=((1-pickerState.v)*100)+'%';
document.getElementById('hueCursor').style.left=(pickerState.h/360*100)+'%';
var rgb=hsvToRgb(pickerState.h,pickerState.s,pickerState.v);
var hex=rgbToHex(rgb.r,rgb.g,rgb.b);
document.getElementById('previewBaru').style.background=hex;
document.getElementById('inputHex').value=hex.toUpperCase();
document.getElementById('inputR').value=Math.round(rgb.r);
document.getElementById('inputG').value=Math.round(rgb.g);
document.getElementById('inputB').value=Math.round(rgb.b);
}
function dariInputHex(val){
var hex=validasiHex(val);
if(!hex)return;
var rgb=hexToRgb(hex);
var hsv=rgbToHsv(rgb.r,rgb.g,rgb.b);
pickerState.h=hsv.h;
pickerState.s=hsv.s;
pickerState.v=hsv.v;
updatePickerUI();
}
function dariInputRGB(){
var r=parseInt(document.getElementById('inputR').value)||0;
var g=parseInt(document.getElementById('inputG').value)||0;
var b=parseInt(document.getElementById('inputB').value)||0;
var hsv=rgbToHsv(r,g,b);
pickerState.h=hsv.h;
pickerState.s=hsv.s;
pickerState.v=hsv.v;
updatePickerUI();
}
function tutupPicker(){
document.getElementById('colorModal').classList.remove('show');
}
function konfirmPicker(){
var rgb=hsvToRgb(pickerState.h,pickerState.s,pickerState.v);
var hex=rgbToHex(rgb.r,rgb.g,rgb.b);
var target=pickerState.target;
var id='pick'+target.charAt(0).toUpperCase()+target.slice(1);
document.getElementById(id).value=hex;
document.getElementById('display-'+target).style.background=hex;
var hi=document.getElementById('hex'+target.charAt(0).toUpperCase()+target.slice(1));
if(hi)hi.value=hex;
gantiCustom();
tutupPicker();
}
function dariHex(jenis,nilai){
var hex=validasiHex(nilai);
if(!hex){alert('Kode HEX tidak valid! Contoh: #9b59b6');return;}
var id='pick'+jenis.charAt(0).toUpperCase()+jenis.slice(1);
document.getElementById(id).value=hex;
document.getElementById('display-'+jenis).style.background=hex;
gantiCustom();
}
function pakaiPreset(nama){
var p=presetTema[nama];
if(!p)return;
document.getElementById('pickBody').value=p.body;
document.getElementById('pickProfil').value=p.profil;
document.getElementById('pickAksen').value=p.aksen;
document.getElementById('display-body').style.background=p.body;
document.getElementById('display-profil').style.background=p.profil;
document.getElementById('display-aksen').style.background=p.aksen;
gantiCustom();
}
function acakWarna(){
var huruf='0123456789ABCDEF';
function rnd(){
var w='#';
for(var i=0;i<6;i++)w+=huruf[Math.floor(Math.random()*16)];
return w;
}
var b=rnd(),p=rnd(),a=rnd();
document.getElementById('pickBody').value=b;
document.getElementById('pickProfil').value=p;
document.getElementById('pickAksen').value=a;
document.getElementById('display-body').style.background=b;
document.getElementById('display-profil').style.background=p;
document.getElementById('display-aksen').style.background=a;
gantiCustom();
}
function applyBackground(warnaBody){
if(backgroundAktif==='none'){
document.body.style.backgroundImage='none';
document.body.style.backgroundColor=warnaBody;
}else{
document.body.style.backgroundImage="linear-gradient("+warnaBody+"CC,"+warnaBody+"CC),url('"+backgroundAktif+"')";
document.body.style.backgroundSize='cover';
document.body.style.backgroundPosition='center';
document.body.style.backgroundAttachment='fixed';
document.body.style.backgroundColor=warnaBody;
}
document.body.style.color=warnaTeksKontras(warnaBody);
}
function gantiBackground(namaGambar){
backgroundAktif=namaGambar;
var warnaBody=document.getElementById('pickBody').value||'#1a1a2e';
applyBackground(warnaBody);
simpanPengaturan();
}
function applySemuaWarna(){
var bodyColor=document.getElementById('pickBody').value;
var profilColor=document.getElementById('pickProfil').value;
var aksenColor=document.getElementById('pickAksen').value;
var teksAksen=warnaTeksKontras(aksenColor);
applyBackground(bodyColor);
var profil=document.querySelector('.profil');
if(profil){profil.style.backgroundColor=profilColor;profil.style.borderColor=aksenColor;}
var avatar=document.querySelector('.avatar');
if(avatar)avatar.style.borderColor=aksenColor;
var judul=document.querySelector('h1');
if(judul)judul.style.color=aksenColor;
var kotak=document.querySelector('.kotak-teks');
if(kotak){kotak.style.borderColor=aksenColor;kotak.style.backgroundColor=profilColor+'D9';}
var tombolList=document.querySelectorAll('.tombol,.tombol-kecil,.tombol-simpan');
for(var i=0;i<tombolList.length;i++){
tombolList[i].style.backgroundColor=aksenColor;
tombolList[i].style.color=teksAksen;
}
var tw=document.querySelector('.tombol-warna');
if(tw)tw.style.backgroundColor=aksenColor;
}
function gantiCustom(){
applySemuaWarna();
var profil=document.querySelector('.profil');
if(profil){profil.classList.remove('animate');void profil.offsetWidth;profil.classList.add('animate');}
var gir=document.getElementById('tombolGir');
if(gir){gir.classList.add('active');setTimeout(function(){gir.classList.remove('active');},500);}
simpanPengaturan();
}

function simpanPalet(){
var body=document.getElementById('pickBody').value;
var profil=document.getElementById('pickProfil').value;
var aksen=document.getElementById('pickAksen').value;
if(palets.length>=8){alert('Palet udah penuh (maks 8).');return;}
var namaDefault=namaKeren[palets.length%namaKeren.length];
var nama=prompt('Beri nama palet ini:',namaDefault);
if(nama===null)return;
if(nama.trim()==='')nama=namaDefault;
palets.push({nama:nama,body:body,profil:profil,aksen:aksen});
simpanPaletKeStorage();
renderPalets();
}
function editPalet(index){
var p=palets[index];
var pilihan=prompt('Edit "'+p.nama+'":\n1=Ganti nama\n2=Update warna\n3=Hapus','1');
if(pilihan==='1'){
var nb=prompt('Nama baru:',p.nama);
if(nb&&nb.trim()!==''){p.nama=nb;simpanPaletKeStorage();renderPalets();}
}else if(pilihan==='2'){
p.body=document.getElementById('pickBody').value;
p.profil=document.getElementById('pickProfil').value;
p.aksen=document.getElementById('pickAksen').value;
simpanPaletKeStorage();renderPalets();
}else if(pilihan==='3'){
if(confirm('Hapus palet "'+p.nama+'"?')){
palets.splice(index,1);simpanPaletKeStorage();renderPalets();
}
}
}
function exportPalet(){
if(palets.length===0){alert('Belum ada palet.');return;}
var data=JSON.stringify(palets,null,2);
var blob=new Blob([data],{type:'application/json'});
var url=URL.createObjectURL(blob);
var link=document.createElement('a');
link.href=url;
link.download='justpixel-palet.json';
link.click();
URL.revokeObjectURL(url);
}
function simpanPaletKeStorage(){
localStorage.setItem('justpixelPalets',JSON.stringify(palets));
}
function loadPalets(){
var data=localStorage.getItem('justpixelPalets');
if(data){try{palets=JSON.parse(data);}catch(e){palets=[];}}
renderPalets();
}
function renderPalets(){
var c=document.getElementById('paletList');
if(!c)return;
c.innerHTML='';
if(palets.length===0){
c.innerHTML='<p style="font-size:9px;opacity:.5">Belum ada palet</p>';
return;
}
for(var i=0;i<palets.length;i++){
(function(idx){
var p=palets[idx];
var card=document.createElement('div');
card.className='palet-card';
var dots=document.createElement('div');
dots.className='palet-dots';
var wa=[p.body,p.profil,p.aksen];
for(var j=0;j<3;j++){
var d=document.createElement('div');
d.className='palet-dot';
d.style.backgroundColor=wa[j];
dots.appendChild(d);
}
var name=document.createElement('span');
name.className='palet-name';
name.textContent=p.nama;
var editBtn=document.createElement('button');
editBtn.className='palet-edit';
editBtn.textContent='Edit';
editBtn.onclick=function(e){e.stopPropagation();editPalet(idx);};
card.appendChild(dots);
card.appendChild(name);
card.appendChild(editBtn);
card.onclick=function(){
document.getElementById('pickBody').value=p.body;
document.getElementById('pickProfil').value=p.profil;
document.getElementById('pickAksen').value=p.aksen;
document.getElementById('display-body').style.background=p.body;
document.getElementById('display-profil').style.background=p.profil;
document.getElementById('display-aksen').style.background=p.aksen;
gantiCustom();
};
c.appendChild(card);
})(i);
}
}

function updateJam(){
var now=new Date();
var jam=String(now.getHours()).padStart(2,'0');
var menit=String(now.getMinutes()).padStart(2,'0');
var detik=String(now.getSeconds()).padStart(2,'0');
var hariArr=['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
var bulanArr=['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
var elJam=document.getElementById('jamRealtime');
var elTgl=document.getElementById('tanggalRealtime');
if(elJam)elJam.textContent=jam+':'+menit+':'+detik;
if(elTgl)elTgl.textContent=hariArr[now.getDay()]+', '+now.getDate()+' '+bulanArr[now.getMonth()];
}

function playClick(){
try{
var ctx=new (window.AudioContext||window.webkitAudioContext)();
var osc=ctx.createOscillator();
var g=ctx.createGain();
osc.connect(g);
g.connect(ctx.destination);
osc.type='square';
osc.frequency.setValueAtTime(800,ctx.currentTime);
osc.frequency.exponentialRampToValueAtTime(400,ctx.currentTime+0.08);
g.gain.setValueAtTime(0.06,ctx.currentTime);
g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.1);
osc.start(ctx.currentTime);
osc.stop(ctx.currentTime+0.1);
}catch(e){}
}
function attachSound(){
var list=document.querySelectorAll('button,.tombol,.tombol-kecil,.tombol-simpan,.color-display,.btn-copy');
for(var i=0;i<list.length;i++)list[i].addEventListener('click',playClick);
}

var tapCount=0,tapTimer;
function tapAvatar(){
tapCount++;
clearTimeout(tapTimer);
tapTimer=setTimeout(function(){tapCount=0;},1500);
if(tapCount>=5){aktifkanEasterEgg();tapCount=0;}
}
function aktifkanEasterEgg(){
document.body.classList.add('easter-egg');
var warnaArr=['#9b59b6','#f1c40f','#e74c3c','#3498db','#2ecc71','#e67e22'];
var daftar=[];
for(var i=0;i<50;i++){
var conf=document.createElement('div');
conf.className='confetti';
conf.style.left=Math.random()*100+'%';
conf.style.background=warnaArr[Math.floor(Math.random()*6)];
conf.style.animationDelay=(Math.random()*1)+'s';
conf.style.width=(5+Math.random()*10)+'px';
conf.style.height=(5+Math.random()*10)+'px';
document.body.appendChild(conf);
daftar.push(conf);
}
setTimeout(function(){
for(var k=0;k<daftar.length;k++){
if(daftar[k]&&daftar[k].parentNode)daftar[k].parentNode.removeChild(daftar[k]);
}
},4000);
try{
var ctx=new (window.AudioContext||window.webkitAudioContext)();
var nada=[523,659,784,1047];
for(var n=0;n<nada.length;n++){
var osc=ctx.createOscillator();
var g=ctx.createGain();
osc.connect(g);
g.connect(ctx.destination);
osc.type='square';
osc.frequency.value=nada[n];
g.gain.setValueAtTime(0.1,ctx.currentTime+n*0.1);
g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+n*0.1+0.15);
osc.start(ctx.currentTime+n*0.1);
osc.stop(ctx.currentTime+n*0.1+0.15);
}
}catch(e){}
setTimeout(function(){document.body.classList.remove('easter-egg');},6000);
alert('EASTER EGG AKTIF!');
}

function initScrollAnim(){
var elements=document.querySelectorAll('.scroll-anim');
if('IntersectionObserver' in window){
var observer=new IntersectionObserver(function(entries){
for(var i=0;i<entries.length;i++){
if(entries[i].isIntersecting){
entries[i].target.classList.add('muncul');
observer.unobserve(entries[i].target);
}
}
},{threshold:.15,rootMargin:'0px 0px -50px 0px'});
for(var j=0;j<elements.length;j++)observer.observe(elements[j]);
}else{
for(var k=0;k<elements.length;k++)elements[k].classList.add('muncul');
}
}

var musikNyala=false;
var musikCtx=null;
var musikInterval=null;
var melodiIndex=0;
var melodi=[523.25,587.33,659.25,698.46,783.99,880,987.77,1046.5,880,783.99,698.46,659.25,587.33,523.25,493.88,440];
var bass=[130.81,130.81,146.83,146.83,164.81,164.81,174.61,174.61];
function mainkanNada(freq,durasi,tipe,vol){
if(!musikCtx)return;
var osc=musikCtx.createOscillator();
var g=musikCtx.createGain();
osc.connect(g);
g.connect(musikCtx.destination);
osc.type=tipe||'square';
osc.frequency.value=freq;
g.gain.setValueAtTime(vol,musikCtx.currentTime);
g.gain.exponentialRampToValueAtTime(0.001,musikCtx.currentTime+durasi);
osc.start(musikCtx.currentTime);
osc.stop(musikCtx.currentTime+durasi+0.05);
}
function toggleMusik(){
var btn=document.getElementById('btnMusik');
var icon=document.getElementById('iconMusik');
if(!musikNyala){
try{
if(!musikCtx)musikCtx=new (window.AudioContext||window.webkitAudioContext)();
if(musikCtx.state==='suspended')musikCtx.resume();
}catch(e){alert('Audio tidak didukung di HP ini');return;}
musikNyala=true;
if(btn)btn.classList.add('nyala');
if(icon)icon.innerHTML='<path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 7.97v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>';
musikInterval=setInterval(function(){
mainkanNada(melodi[melodiIndex%melodi.length],0.25,'square',0.035);
if(melodiIndex%2===0)mainkanNada(bass[Math.floor(melodiIndex/2)%bass.length],0.35,'triangle',0.05);
melodiIndex++;
},250);
}else{
musikNyala=false;
if(btn)btn.classList.remove('nyala');
if(icon)icon.innerHTML='<path d="M16.5 12A4.5 4.5 0 0 0 14 7.97v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51A8.8 8.8 0 0 0 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06a9 9 0 0 0 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>';
if(musikInterval){clearInterval(musikInterval);musikInterval=null;}
}
}

function transisiHalaman(url,external){
if(external){window.open(url,'_blank');return;}
document.body.classList.add('page-exit');
setTimeout(function(){window.location.href=url;},350);
}
function copyLink(teks,btn){
function sukses(){
var asli=btn.textContent;
btn.textContent='OK';
setTimeout(function(){btn.textContent=asli;},1200);
}
if(navigator.clipboard){
navigator.clipboard.writeText(teks).then(sukses).catch(function(){fallbackCopy(teks);sukses();});
}else{fallbackCopy(teks);sukses();}
}
function fallbackCopy(teks){
var inp=document.createElement('textarea');
inp.value=teks;
inp.style.position='fixed';
inp.style.opacity='0';
document.body.appendChild(inp);
inp.select();
try{document.execCommand('copy');}catch(e){}
document.body.removeChild(inp);
}
function scrollToTop(){window.scrollTo({top:0,behavior:'smooth'});}
window.addEventListener('scroll',function(){
var btn=document.getElementById('btnTop');
if(!btn)return;
if(window.scrollY>400)btn.classList.add('show');
else btn.classList.remove('show');
});

window.addEventListener('DOMContentLoaded',function(){
muatPengaturan();
loadPalets();
updateJam();
setInterval(updateJam,1000);
initScrollAnim();
attachSound();
updateHitCounter();
});